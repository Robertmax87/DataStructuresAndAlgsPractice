package com;

public class LeetCodeSolution {
    public static void main(String[] args){
        int[] a = {3,2,4};
        int [] he = twoSum(a,6);
        for (int i = 0; i<he.length; i++){
            System.out.println(he[i]);

        }

    }
    public static int[] twoSum(int[] nums, int target){
        for(int i = 0; i<nums.length-1; i++){
            int starter = i;
            for( int next = 1; next<nums.length; next++){
                if (nums[starter] + nums[next] == target){
                    int[] a = {starter, next};

                    return a;
                }
            }
        }
        throw new ArrayStoreException("nums doesn't work");
    }

}
